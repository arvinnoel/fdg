using System.Threading.Tasks;

namespace webapi.Contracts
{
    public interface IMainHub
    {
         Task UpdateClients();
    }
}