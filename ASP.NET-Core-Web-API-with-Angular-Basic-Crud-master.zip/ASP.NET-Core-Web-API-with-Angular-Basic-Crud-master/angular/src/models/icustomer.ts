export interface Customer {
    customerId: number;
    firstname: string;
    lastname: string;
}
